from flask import Flask, render_template, jsonify, request, send_file
import rospy
from clover import srv
from std_msgs.msg import Bool
import threading
import numpy as np
import subprocess
import time, math, os, json, io, base64

from sensor_msgs.msg import Image, PointCloud
import logging

import platform
from cloverAPI import CloverAPI
from aruco_pose.msg import MarkerArray
from cv_bridge import CvBridge, CvBridgeError


app = Flask(__name__)

plat = platform.system()
if plat == 'Linux' or plat == 'Darwin':
    runner = 'python3'
else:
    runner = 'python'


log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)


app = Flask(__name__, static_folder='static')
W, H = 800, 800          # Размер изображения
MARGIN = 40  

drone_state = {'x': 0.0, 'y': 0.0, 'z': 0.0, 'yaw': 0.0}
cuts = []
mission_status = 'idle'  # idle | flying | aborted | killed
search_status = False
coords = []
proc = None

get_telemetry = rospy.ServiceProxy('get_telemetry', srv.GetTelemetry)
navigate = rospy.ServiceProxy('navigate', srv.Navigate)



data = {
    "pipes": [
        {
            "start": {
                "x": 0,
                "y": 0,
                "z": 0
            },
            "end": {
                "x": 0,
                "y": 0,
                "z": 0
            },
            "color": "#ff0000"
        }
    ]
}

with open('static/config/pipes.json', 'w') as f:
    json.dump(data, f, indent=4) # Reset config before the app starts


def find_nearest_building(drone_x, drone_y, buildings_file='detected_buildings.json'):
    """
    Находит ближайшее здание к координатам дрона.
    
    Args:
        drone_x, drone_y: координаты дрона (метры)
        buildings_file: путь к JSON-файлу со зданиями
    
    Returns:
        dict: ближайшее здание + расстояние, или None если зданий нет
    """
    try:
        # Читаем файл со зданиями
        if not os.path.exists(buildings_file):
            return None
            
        with open(buildings_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        buildings = data.get('buildings', [])
        if not buildings:
            return None
        
        nearest = None
        min_distance = float('inf')
        
        for building in buildings:
            # Координаты центра здания
            b_x = building.get('x', 0)
            b_y = building.get('y', 0)
            
            # Учитываем размеры здания для более точного расстояния
            width = building.get('width', 0)
            depth = building.get('depth', 0)
            
            # Вычисляем границы здания
            x_min, x_max = b_x - width/2, b_x + width/2
            y_min, y_max = b_y - depth/2, b_y + depth/2
            
            # Если дрон внутри здания — расстояние 0
            if x_min <= drone_x <= x_max and y_min <= drone_y <= y_max:
                distance = 0
            else:
                # Расстояние до ближайшей границы здания
                dx = max(x_min - drone_x, 0, drone_x - x_max)
                dy = max(y_min - drone_y, 0, drone_y - y_max)
                distance = math.sqrt(dx**2 + dy**2)
            
            # Обновляем ближайшее здание
            if distance < min_distance:
                min_distance = distance
                nearest = {
                    **building,
                    'distance': round(distance, 3),
                    'direction': calculate_direction(drone_x, drone_y, b_x, b_y)
                }
        
        return nearest
        
    except Exception as e:
        print(f"❌ Ошибка поиска здания: {e}")
        return None


def calculate_direction(x1, y1, x2, y2):
    """
    Вычисляет направление от точки 1 к точке 2 в градусах.
    0° = север (+Y), 90° = восток (+X)
    """
    angle_rad = math.atan2(x2 - x1, y2 - y1)  # Y — север, X — восток
    angle_deg = math.degrees(angle_rad)
    return round((angle_deg + 360) % 360, 1)


def calculate_image_position() -> 'tuple[float, float, float, float]':
    """
    Ваша функция: вычисление позиции и масштаба изображения карты.
    Возвращает: (x, y, lx, ly) — смещение и размеры в мировых координатах.
    """
    aruco_map = get_markers_from_ros()  # Получаем маркеры из ROS
    if not aruco_map:
        return 0, 0, W, H
    
    left = min(aruco_map, key=lambda x: x["x"] - x["length"] / 2)
    right = max(aruco_map, key=lambda x: x["x"] + x["length"] / 2)
    top = max(aruco_map, key=lambda x: x["y"] + x["length"] / 2)
    bottom = min(aruco_map, key=lambda x: x["y"] - x["length"] / 2)
    dx = right["x"] - left["x"]
    dy = top["y"] - bottom["y"]
    
    if dx >= dy:
        k1, k2 = right["length"] / dx, left["length"] / dx
        dx_px = (2 * W - 4 * MARGIN) / (2 + k1 + k2)
        scale = dx / dx_px
        margin_y = (H - (W - 2 * MARGIN) * (dy + (top["length"] + bottom["length"]) / 2) / (dx + (right["length"] + left["length"]) / 2)) / 2
        y = top["y"] + margin_y * scale + top["length"] / 2
        x = left["x"] - MARGIN * scale - left["length"] / 2
        ly, lx = H * scale, W * scale
    else:
        k1, k2 = top["length"] / dy, bottom["length"] / dy  # Исправлено: было dx, должно быть dy
        dy_px = (2 * H - 4 * MARGIN) / (2 + k1 + k2)
        scale = dy / dy_px
        margin_x = (W - (H - 2 * MARGIN) * (dx + (right["length"] + left["length"]) / 2) / (dy + (top["length"] + bottom["length"]) / 2)) / 2
        y = top["y"] + MARGIN * scale + top["length"] / 2
        x = left["x"] - margin_x * scale - left["length"] / 2
        ly, lx = H * scale, W * scale
    return x, y, lx, ly


def get_markers_from_ros():
    """Получает маркеры из топика /aruco_map/map"""
    try:
        msg = rospy.wait_for_message('/aruco_map/map', MarkerArray)
        markers = []
        for m in msg.markers:
            markers.append({
                'id': m.id,
                'x': m.pose.position.x,
                'y': m.pose.position.y,
                'z': 0,
                'length': m.length
            })
        return markers
    except Exception as e:
        print('get markers :', e)
        return []


def get_map_image_from_ros():
    """Получает изображение карты из топика /aruco_map/image"""
    try:
        img_msg = rospy.wait_for_message('/aruco_map/image', Image, timeout=2)
        cv_image = bridge.imgmsg_to_cv2(img_msg, desired_encoding='bgr8')
        # Конвертируем BGR -> RGB для PIL/base64
        rgb_image = cv_image[:, :, ::-1]
        return rgb_image
    except CvBridgeError as e:
        print(e)
        print(f"CvBridge error: {e}")
        return None
    except Exception as e:
        print(f"Error getting map image: {e}")
        return None


def image_to_base64(cv_image_rgb):
    """Конвертирует numpy array (RGB) в base64-строку"""
    from PIL import Image
    img = Image.fromarray(cv_image_rgb)
    buffer = io.BytesIO()
    img.save(buffer, format='PNG', optimize=True)
    buffer.seek(0)
    return base64.b64encode(buffer.read()).decode('utf-8')


def get_map_data():
    """
    Получает изображение карты + маркеры + вычисляет метаданные.
    Центрирует первый маркер в (0, 0).
    """
    # Получаем данные
    markers = get_markers_from_ros()
    if not markers: 
        print(' -- WARNING : MARKERS NOT RECEIVED FROM ROS -- ')

    # print(markers)
    
    map_image = get_map_image_from_ros()
    
    try:
        if not map_image:
            print(' -- WARNING : MAP NOT RECEIVED FROM ROS -- ')
            return None
    except:
        pass
        
    # Вычисляем позицию и масштаб через вашу функцию
    x_offset, y_offset, width_world, height_world = calculate_image_position()
    
    # # Если есть маркеры — центрируем на первом
    center_marker = markers[0] if markers else None
    # if center_marker:
        # Сдвиг координат: чтобы первый маркер оказался в (0, 0)
        # shift_x = -center_marker['x']
        # shift_y = -center_marker['y']
        # x_offset += shift_x
        # y_offset += shift_y
    x_offset = -0.72
    y_offset = -1.69

    # print(width_world, height_world)
    k = 0.7
    width_world += k
    height_world += k
    
    # Метаданные для фронтенда
    metadata = {
        'offset_x': x_offset,           # Смещение левого края текстуры (мировые координаты)
        'offset_y': y_offset,           # Смещение верхнего края текстуры
        'width_world': width_world,     # Ширина текстуры в метрах
        'height_world': height_world,   # Высота текстуры в метрах
        'center_marker_id': center_marker['id'] if center_marker else None,
        'markers_count': len(markers)
    }
    
    # Конвертируем изображение в base64
    img_base64 = image_to_base64(map_image)

    return {
        'image': f'data:image/png;base64,{img_base64}',
        'metadata': metadata,
        'markers': markers
    }


@app.before_request
def get_clover_instance():
    global clover, bridge
    # rospy.init_node('')
    clover = CloverAPI()    
    bridge = CvBridge()


# === Глобальная переменная для линий ===
flight_lines = []  # [{'start': {'x': 0, 'y': 0, 'z': 0.5}, 'end': {'x': 1, 'y': 1, 'z': 0.5}, 'color': '#00ff00'}]


@app.route('/lines')
def get_lines():
    global flight_lines
    """Отдаёт список линий для отрисовки (маршрут, путь и т.д.)"""
    return jsonify({
        'lines': flight_lines,
        'count': len(flight_lines)
    })


def navigate_wait(x=0, y=0, z=0, yaw=float('nan'), speed=0.5, frame_id='', auto_arm=False, tolerance=0.2):
    navigate(x=x, y=y, z=z, yaw=yaw, speed=speed, frame_id=frame_id, auto_arm=auto_arm)

    while not rospy.is_shutdown():
        telem = get_telemetry(frame_id='navigate_target')
        if math.sqrt(telem.x ** 2 + telem.y ** 2 + telem.z ** 2) < tolerance:
            break
        rospy.sleep(0.2)


@app.route('/map')
def get_map():
    print(' -- Called endpoint /map -- ')
    """Отдаёт карту: изображение + метаданные + маркеры"""
    result = get_map_data()
    
    if result is None:
        return jsonify({
            'error': 'Failed to get map from ROS',
            'markers': [],
            'texture': None,
            'texture_meta': None
        }), 503
    
    return jsonify({
        'markers': result['markers'],
        'source': 'ros',
        'count': len(result['markers']),
        'texture': result['image'],
        'texture_meta': result['metadata']
    })


@app.route('/drone')
def get_drone():
    global search_status, drone_state
    try:
        # Запрос телеметрии
        telem = get_telemetry(frame_id='aruco_map')
        # print(telem)
        
        if not telem.x or telem.x == np.nan or math.isnan(telem.x):
            telem.x = 0
        
        if not telem.y or telem.y == np.nan or math.isnan(telem.y) :
            telem.y = 0
        
        if not telem.z or telem.z == np.nan or math.isnan(telem.z) :
            telem.z = 0

        if not telem.yaw or telem.yaw == np.nan or math.isnan(telem.yaw) :
            telem.yaw = -math.pi / 2
        else: 
            telem.yaw -= math.pi / 2

        # Формирование ответа
        drone_state = {
            'x': telem.x, 
            'y': telem.y, 
            'z': telem.z,      # Добавляем высоту (обычно ~0.5-1.0м)
            'yaw': telem.yaw   # Угол поворота в радианах
        }
        
        # # Логика записи маршрута
        # if search_status:
        #     coords.append(drone_state)
        # print(drone_state)
        return jsonify(drone_state)
    except Exception as e:
        print('drone error:', e)
        # Возвращаем заглушку при ошибке, чтобы фронтенд не падал
        return jsonify({'x': 0, 'y': 0, 'z': 0.5, 'yaw': 0})


# @app.route('/state', methods=['GET'])
# def get_state():
#     try:
#         bat = clover.get_battery_state()
#         # mavros = clover.get_state()
#         return jsonify({
#             "voltage": bat.voltage, 
#             "percentage": bat.percentage
#         })
#     except rospy.ROSException as e:
#         return jsonify({"error": str(e)}), 500


@app.route('/map/texture.png')
def get_map_texture():
    print('map fetched')
    """Прямая отдача PNG-изображения карты"""
    map_image = get_map_image_from_ros()
    if map_image is None:
        return jsonify({'error': 'No map image available'}), 503
    
    return send_file(
        io.BytesIO(base64.b64decode(image_to_base64(map_image))),
        mimetype='image/png',
        download_name='map.png'
    )


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/route')
def get_route():
    return coords


@app.route('/cuts')
def get_cuts():
    global cuts
    return jsonify(cuts)


def monitor_process():
    global proc, mission_status
    while True:
        # Если процесс запущен
        if proc is not None:
            # poll() возвращает None, если процесс еще работает, 
            # и код завершения, если процесс завершился
            if proc.poll() is not None:
                print("Mission process finished.")
                mission_status = 'idle'

                #

                proc = None  # Сбрасываем ссылку, чтобы не проверять старый процесс
        time.sleep(0.5)  # Проверка каждые полсекунды

def cuts_callback(msg):
    global cuts

    new_taps = []
    for i in range(0, len(msg.points)):
        new_taps.append({'x': msg.points[i].x, 'y': msg.points[i].y})
    cuts = new_taps


def cut_updater():
    rospy.Subscriber('/tubes', PointCloud, cuts_callback) 
    rospy.spin()


if __name__ == '__main__':
    rospy.init_node('web_bridge', anonymous=True, disable_signals=True)
    # threading.Thread(target=ros_listener, daemon=True).start()
    threading.Thread(target=cut_updater, daemon=True).start()
    threading.Thread(target=monitor_process, daemon=True).start()
    
    app.run(host='127.0.10.10', port=5000, debug=True)
