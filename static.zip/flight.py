import rospy, math
from clover import srv
from std_srvs.srv import Trigger
from sensor_msgs.msg import PointCloud

rospy.init_node('flight')

get_telemetry = rospy.ServiceProxy('get_telemetry', srv.GetTelemetry)
navigate = rospy.ServiceProxy('navigate', srv.Navigate)
navigate_global = rospy.ServiceProxy('navigate_global', srv.NavigateGlobal)
set_altitude = rospy.ServiceProxy('set_altitude', srv.SetAltitude)
set_yaw = rospy.ServiceProxy('set_yaw', srv.SetYaw)
set_yaw_rate = rospy.ServiceProxy('set_yaw_rate', srv.SetYawRate)
set_position = rospy.ServiceProxy('set_position', srv.SetPosition)
set_velocity = rospy.ServiceProxy('set_velocity', srv.SetVelocity)
set_attitude = rospy.ServiceProxy('set_attitude', srv.SetAttitude)
set_rates = rospy.ServiceProxy('set_rates', srv.SetRates)
land = rospy.ServiceProxy('land', Trigger)

def navigate_wait(x=0, y=0, z=0, yaw=float('nan'), speed=0.5, frame_id='', auto_arm=False, tolerance=0.2):
    navigate(x=x, y=y, z=z, yaw=yaw, speed=speed, frame_id=frame_id, auto_arm=auto_arm)

    while not rospy.is_shutdown():
        telem = get_telemetry(frame_id='navigate_target')
        if math.sqrt(telem.x ** 2 + telem.y ** 2 + telem.z ** 2) < tolerance:
            break
        rospy.sleep(0.2)

def land_wait():
    land()
    while get_telemetry().armed:
        rospy.sleep(0.2)

coords_aruco = [
    [0, 1],
    [-2, 0.8],
    [2, 2.5],
    [-2, 4],
    [3, 2],
    [3.6, 2.7],
    [4.5, 1.6],
    [4.5, 3.4],
    # [0.7, 9],
    # [-0.5, 9.3],
    # [9.5, 6.8]
]

navigate_wait(z = 2, frame_id='body', auto_arm=True)

points = []

publisher = rospy.Publisher("/cuts", PointCloud, queue_size=10)


for cord in coords_aruco:
    navigate_wait(x = cord[0], y = cord[1], z = 2, frame_id='aruco_map', tolerance=0.1)

    # get_telemetry()
    print(f'(x = {cord[0]}, y = {cord[1]})')
    points.append((cord[0], cord[1]))
    points_msg = PointCloud()
    points_msg.header.frame_id = "aruco_map"
    points_msg.header.stamp = rospy.Time.now()
    points_msg.points = points
    publisher.publish(points_msg)

    rospy.sleep(1)
navigate_wait(x = 0, y = 0, z = 1, frame_id='aruco_map')
land_wait()
